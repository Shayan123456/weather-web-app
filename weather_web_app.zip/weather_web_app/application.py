import os
import requests
import json
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash
from datetime import datetime
import time
import unicodedata

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True


# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.context_processor
def utility_processor():
    def total_cash():
        cash = 0
        user_shares = db.execute("SELECT * FROM symbols WHERE user_id = ?", session["user_id"])
        for share in user_shares:
            res = lookup(share['symbol'])
            s_p = res['price']
            cash += s_p * share['shares']
        user = db.execute("SELECT * FROM users WHERE id = ?", session["user_id"])
        cash += float(user[0]['cash'])
        print(cash)
        return f"{cash:,.2f}"

    return dict(total_cash=total_cash)


def countdays(secs):
    days = secs // 86400
    secs -= (days * 86400)
    hours = secs // 3600
    secs -= (hours * 3600)
    minutes = secs // 60
    secs -= (minutes * 60)
    txt = ""
    if minutes:
        txt += f"{minutes:.0f} Minutes "
    return f"{txt}{secs:.0f} Secs"


def con_maker(en_con):
    en_con = str(en_con).lower()
    icon = ""
    if "clear" in en_con:
        icon = "https://cdn3.iconfinder.com/data/icons/weather-172/24/_clear_sun-512.png"
    elif "few clouds" in en_con:
        icon = "https://cdn2.iconfinder.com/data/icons/weather-147/59/partly_cloudy-512.png"
    elif "scattered clouds" in en_con or "overcast clouds" in en_con:
        icon = "https://cdn3.iconfinder.com/data/icons/aami-web-internet/64/aami9-60-512.png"
    elif "broken clouds" in en_con or "clouds" in en_con:
        icon = "https://cdn3.iconfinder.com/data/icons/aami-web-internet/64/aami5-19-512.png"
    elif "shower rain" in en_con:
        icon = "https://cdn1.iconfinder.com/data/icons/weather-189/64/weather-icons-rainy-2-512.png"
    elif "rain" in en_con:
        icon = "https://cdn2.iconfinder.com/data/icons/unigrid-weather/58/027_sun_clouds_rain_rainy_day_daylight_weather_2-512.png"
    elif "thunderstorm" in en_con:
        icon = "https://cdn4.iconfinder.com/data/icons/weather-790/32/thunderstorm-512.png"
    elif "snow" in en_con:
        icon = "https://cdn1.iconfinder.com/data/icons/weather-189/64/weather-icons-snowy-512.png"
    elif "mist" in en_con:
        icon = "https://cdn2.iconfinder.com/data/icons/weather-242/44/mist-512.png"
    return icon


@app.template_filter('str_datetime')
def str_datetime(s):
    local_time = time.time()
    diff = local_time - int(s)
    date_time_obj = countdays(diff)
    return date_time_obj


@app.template_filter('date_time')
def str_datetime(unix_timestamp):
    local_time = datetime.fromtimestamp(unix_timestamp)
    t_time = local_time.strftime("%Y-%m-%d")
    print(t_time)
    return t_time


@app.template_filter('w_icon')
def w_icon(weather):
    print(weather, con_maker(weather))
    return con_maker(weather)


@app.route("/")
def index():
    print(request.remote_addr)
    url = f"https://ip-geolocation.whoisxmlapi.com/api/v1?apiKey=at_cnKT5tbHBRibHPzSsD9z5CnBaBtWQ&ipAddress={request.remote_addr}"
    r = requests.get(url)
    j = json.loads(r.text)
    print(j)
    if j['location']['city']:
        city = j['location']['city']
        city = (unicodedata.normalize('NFKD', city).encode('ascii', 'ignore')).decode("utf-8")

        req = requests.get(
            f"https://openweathermap.org/data/2.5/find?q={city}&type=like&sort=population&cnt=30&appid=439d4b804bc8187953eb36d2a8c26a02&_=1586888241616").json()
        print(city, req)
        city_id = req['list'][0]['id']
        daily_forecast = requests.get(
            f"https://openweathermap.org/data/2.5/forecast/daily/?appid=439d4b804bc8187953eb36d2a8c26a02&id={city_id}&units=metric").json()
        now_weather = requests.get(
            f"https://openweathermap.org/data/2.5/weather/?appid=439d4b804bc8187953eb36d2a8c26a02&id={city_id}&units=metric").json()
        print(daily_forecast, now_weather)
        return render_template("index.html", loc=j['location'], daily=daily_forecast, now=now_weather)
    else:
        return render_template("index.html")


def errorhandler(e):
    """Handle error"""
    if not isinstance(e, HTTPException):
        e = InternalServerError()
    return apology(e.name, e.code)


# Listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True, port=8585)
